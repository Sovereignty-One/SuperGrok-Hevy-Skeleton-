---
# Fill in the fields below to create a basic custom agent for your repository.
# The Copilot CLI can be used for local testing: https://gh.io/customagents/cli
# To make this agent available, merge this file into the default repository branch.
# For format details, see: https://gh.io/customagents/config

name:
description:
---

# My Agent

Describe what your agent does here...
works with grok.com and x.ai for collaberation allows private access with user authorization fix broken code and place files properly in folders updating structure keeping maintnence updated for clean runs
