---
name: My Agent
description: Cleanup old outdated code, update the structure, and deploy on a local CI/CD
---

# My Agent

Cleanup old outdated code, update the structure, and deploy on a local CI/CD