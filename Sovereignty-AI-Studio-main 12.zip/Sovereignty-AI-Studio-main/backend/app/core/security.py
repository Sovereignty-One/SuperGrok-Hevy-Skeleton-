# app/core/security.py
from datetime import datetime, timedelta
from typing import Optional

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.config import settings

# bcrypt hashing context
pwd_context = CryptContext(schemes= , deprecated="auto")


def create_access_token(
    data: dict,
    expires_delta: Optional = None,
) -> str:
    """Create a signed JWT access token."""
    to_encode = data.copy()
    expire = (
        datetime.utcnow() + expires_delta
        if expires_delta
        else datetime.utcnow()
        + timedelta(minutes=settings.access_token_expire_minutes)
    )
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.secret_key, algorithm=settings.algorithm)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify plain password against hashed version."""
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    """Hash a plain password."""
    return pwd_context.hash(password)


def verify_token(token: str) -> Optional :
    """Validate JWT and return subject (username) if valid."""
    try:
        payload = jwt.decode(
            token,
            settings.secret_key,
            algorithms= ,
        )
        return payload.get("sub")
    except JWTError:
        return None
